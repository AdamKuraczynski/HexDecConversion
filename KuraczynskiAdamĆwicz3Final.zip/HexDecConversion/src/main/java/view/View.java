/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import java.util.Scanner;
/**
 *
 * @author Adam Kuraczyński
 * @version 1.7
 */
public class View {

    /**
     * Handles decision which type of conversion to choose (later stages)
     * @return - value of choice between conversion types that user types in command line (1 or 2)
     */
    public int userConversionChoice() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Wybierz 1. hex na dec 2. dec na hex. Wpisz 1 lub 2\n");
        return scanner.nextInt();
    }

    /**
     * Handles value to convert
     * @return - value of input that user types in command line
     */
    public String userValueInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Podaj wartosc: ");
        return scanner.nextLine();
    }

    /**
     * Displays result of application
     * @param result - result is final converted value
     */
    public void displayResult(String result) {
        System.out.println("Wynik: " + result);
    }
}