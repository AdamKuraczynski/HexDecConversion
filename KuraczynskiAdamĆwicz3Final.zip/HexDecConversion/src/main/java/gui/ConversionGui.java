package gui;

import model.ConversionException;
import model.Model;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * The ConversionGui class provides a simple GUI for hexadecimal to decimal and decimal to hexadecimal conversion.
 * It accepts command-line arguments for initial setup and allows user interaction for further conversions.
 * @author Adam Kuraczyński
 * @version 1.16
 */
public class ConversionGui {

    private final Model model;
    private DefaultTableModel tableModel;
    private JTable resultTable;

    /**
     * Constructs a ConversionGui instance.
     *
     * @param providedArgs Command-line arguments for initial setup.
     */
    public ConversionGui(String providedArgs) {
        model = new Model();
        createAndShowGUI(providedArgs);
    }

    /**
     * Creates and displays the graphical user interface.
     *
     * @param providedArgs Command-line arguments for initial setup.
     */
    private void createAndShowGUI(String providedArgs) {
        JFrame frame = new JFrame("Konwersja Decimal i HEX");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        JRadioButton rButtonHexToDec = new JRadioButton("HEX -> Decimal");
        JRadioButton rButtonDecToHex = new JRadioButton("Decimal -> HEX");
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(rButtonHexToDec);
        buttonGroup.add(rButtonDecToHex);

        rButtonHexToDec.setToolTipText("Konwersja z HEX na Decimal");
        rButtonHexToDec.setMnemonic('H');
        rButtonDecToHex.setToolTipText("Konwersja z Decimal na HEX");
        rButtonDecToHex.setMnemonic('D');

        JTextField textFieldValueToConvert = new JTextField(10);
        JLabel labelTextFieldValueToConvert = new JLabel("Wprowadź wartość do konwersji: ");
        labelTextFieldValueToConvert.setLabelFor(textFieldValueToConvert);
        textFieldValueToConvert.setToolTipText("Miejce gdzie wprowadzamy wartość do konwersji");
        labelTextFieldValueToConvert.setDisplayedMnemonic('W');

        // Sets the initial value of the text field using providedArgs
        String[] argsArray = providedArgs.split(" ");
        if (argsArray.length == 2) {
            textFieldValueToConvert.setText(argsArray[1]);
            if (argsArray[0].equalsIgnoreCase("h")) {
                rButtonHexToDec.setSelected(true);
            } else if (argsArray[0].equalsIgnoreCase("d")) {
                rButtonDecToHex.setSelected(true);
            } else {
                // Display an error message for invalid first parameter
                displayErrorMessage("Niewłaściwy pierwszy paramet - użyj 'h' dla konwersji z HEX na Decimal lub 'd' dla konwersji z Decimal na HEX");
                return;
            }
        }

        JButton convertButton = new JButton("Konwertuj");

        convertButton.setToolTipText("Rozpocznij konwersję");
        convertButton.setMnemonic('K');

        String[] tableResultColumnNames = {"Rodzaj konwersji", "Dane wejsciowe", "Wynik"};
        tableModel = new DefaultTableModel(null, tableResultColumnNames);

        resultTable = new JTable(tableModel);
        resultTable.setFillsViewportHeight(true);
        resultTable.setToolTipText("Tabela wyników");

        panel.setLayout(new FlowLayout());
        panel.add(rButtonHexToDec);
        panel.add(rButtonDecToHex);
        panel.add(labelTextFieldValueToConvert);
        panel.add(textFieldValueToConvert);
        panel.add(convertButton);

        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(panel, BorderLayout.NORTH);
        frame.getContentPane().add(new JScrollPane(resultTable), BorderLayout.CENTER);

        frame.setSize(800, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        convertButton.addActionListener((ActionEvent e) -> {
            String userInput = textFieldValueToConvert.getText();
            int conversionChoice = rButtonHexToDec.isSelected() ? 1 : (rButtonDecToHex.isSelected() ? 2 : 0);
            performConversionAndDisplay(conversionChoice, userInput);
        });
    }

    /**
     * Performs the conversion and displays the result.
     *
     * @param conversionChoice The type of conversion (1 for HEX to Decimal, 2 for Decimal to HEX).
     * @param userInput        The user input for conversion.
     */
    private void performConversionAndDisplay(int conversionChoice, String userInput) {
        try {
            String result = performConversion(conversionChoice, userInput);
            displayResult(conversionChoice, userInput, result);
        } catch (ConversionException exception) {
            displayErrorMessage("Error during conversion: " + exception.getMessage());
        }
    }

    /**
     * Performs the actual conversion based on user input.
     *
     * @param conversionChoice The type of conversion (1 for HEX to Decimal, 2 for Decimal to HEX).
     * @param userInput        The user input for conversion.
     * @return The result of the conversion.
     * @throws ConversionException If an error occurs during the conversion.
     */
    private String performConversion(int conversionChoice, String userInput) throws ConversionException {
        return switch (conversionChoice) {
            case 1 -> Integer.toString(model.hexToDecimal(userInput));
            case 2 -> model.decimalToHex(userInput);
            default -> "Wybierz rodzaj konwersji";
        };
    }

    /**
     * Displays the conversion result in the table.
     *
     * @param conversionChoice The type of conversion (1 for HEX to Decimal, 2 for Decimal to HEX).
     * @param userInput        The user input for conversion.
     * @param result            The result of the conversion.
     */
    private void displayResult(int conversionChoice, String userInput, String result) {
        Object[] rowData = {getConversionTypeString(conversionChoice), userInput, result};
        tableModel.addRow(rowData);
    }

    /**
     * Gets the conversion type as a string.
     *
     * @param conversionChoice The type of conversion (1 for HEX to Decimal, 2 for Decimal to HEX).
     * @return The conversion type as a string.
     */
    private String getConversionTypeString(int conversionChoice) {
        return (conversionChoice == 1) ? "HEX -> Decimal" : "Decimal -> HEX";
    }

    /**
     * Displays an error message in a dialog box.
     *
     * @param errorMessage The error message to be displayed.
     */
    private void displayErrorMessage(String errorMessage) {
        JOptionPane.showMessageDialog(null, errorMessage, "Error", JOptionPane.WARNING_MESSAGE);
    }

    /**
     * The main method to start the application.
     *
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        String providedArgs = String.join(" ", args);

        SwingUtilities.invokeLater(() -> {
            new ConversionGui(providedArgs);
        });
    }
}