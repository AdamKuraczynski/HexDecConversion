/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import model.ConversionException;
import model.Model;
import view.View;
/**
 *
 * @author Adam Kuraczyński
 * @version 1.11
 */
public class Controller {
    private final Model model;
    private final View view;

    /**
     * Initialization of Controller - thanks to that we are able to communicate with Controller using other objects
     * @param model - allows communication with Model
     * @param view - allows communication with View
     */
    public Controller(Model model, View view) {
        this.model = model;
        this.view = view;
    }

    /**
     * Puts into decimal_value integer value of conversion that transpired in hexToDecimal method of object model
     * @param hexValue - string value put in by user of application
     */
    public void convertHexToDecimal(String hexValue) {
        try {
            int decimalValue = model.hexToDecimal(hexValue);
            view.displayResult(Integer.toString(decimalValue));
        } catch (ConversionException exception) {
            System.out.println("Blad podczas konwersji: " + exception.getMessage());
        }
    }

    /**
     * Puts into hex_value string value of conversion that transpired in decimalToHex method of object model
     * @param decimalValue - integer value put in by user of application
     */
    public void convertDecimalToHex(String decimalValue) {
        try {
            String hexValue = model.decimalToHex(decimalValue);
            view.displayResult(hexValue);
        } catch (ConversionException exception) {
            System.out.println("Blad podczas konwersji: " + exception.getMessage());
        }
    }

    /**
     * Method used to manage user input, depending on choice switch decides which conversion to do
     * If incorrect option is selected it asks you to try again until you do
     */
    public void manageUserInput() {
        int userChoice = view.userConversionChoice();
        switch (userChoice) {
            case 1 -> {
                String hexValue = view.userValueInput();
                convertHexToDecimal(hexValue);
            }
            case 2 -> {
                String decimalValue = view.userValueInput();
                convertDecimalToHex(decimalValue);
            }
            default -> {
                view.displayResult("Bledny wybor, wybierz ponownie");
                manageUserInput();
            }
        }
    }
}