/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */
/**
 * Creates an instance of Model and stores it
 * 
 * @author Adam Kuraczyński
 * @version 1.0
 */
package context;