/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import java.util.Scanner;
/**
 *
 * @author Adam Kuraczyński
 * @version 1.6
 */
public class View {

    /**
     * Gets user choice
     * @return - value of choice between conversion types that user types in command line (1 or 2)
     */
    public int getuserchoice() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose 1. hex to dec 2. dec to hex. Enter 1 or 2\n");
        return scanner.nextInt();
    }

    /**
     * Gets user input
     * @return - value of input that user types in command line
     */
    public String getuserinput() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter input: ");
        return scanner.nextLine();
    }

    /**
     * Displays result of application
     * @param result - result is final converted value
     */
    public void displayResult(String result) {
        System.out.println("Result: " + result);
    }
}