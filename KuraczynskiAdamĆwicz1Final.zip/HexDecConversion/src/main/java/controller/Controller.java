/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import model.Model;
import view.View;
/**
 *
 * @author Adam Kuraczyński
 * @version 1.4
 */
public class Controller {
    private final Model model;
    private final View view;

    /**
     * Initialization of Controller - thanks to that we are able to communicate with Controller using other objects
     * @param model - allows communication with Model
     * @param view - allows communication with View
     */
    public Controller(Model model, View view) {
        this.model = model;
        this.view = view;
    }

    /**
     * Puts into decimal_value integer value of conversion that transpired in hexToDecimal method of object model
     * @param hex_value - string value put in by user of application
     */
    public void convertHexToDecimal(String hex_value) {
        int decimal_value = model.hexToDecimal(hex_value);
        view.displayResult(Integer.toString(decimal_value));
    }

    /**
     * Puts into hex_value string value of conversion that transpired in decimalToHex method of object model
     * @param decimal_value - integer value put in by user of application
     */
    public void convertDecimalToHex(int decimal_value) {
        String hex_value = model.decimalToHex(decimal_value);
        view.displayResult(hex_value);
    }

    /**
     * Method used to manage user input, depending on choice switch decides which conversion to do
     * If incorrect option is selected it asks you to try again until you do
     */
    public void manageUserInput() {
        int userchoice = view.getuserchoice();
        
        switch (userchoice) {
            case 1 -> {
                String userinput = view.getuserinput();
                convertHexToDecimal(userinput);
            }
            case 2 -> {
                String userinput = view.getuserinput();
                int decimal = Integer.parseInt(userinput);
                convertDecimalToHex(decimal);
            }
            default -> {
                view.displayResult("Invalid choice, try again");
                manageUserInput();
            }
        }
    }
}