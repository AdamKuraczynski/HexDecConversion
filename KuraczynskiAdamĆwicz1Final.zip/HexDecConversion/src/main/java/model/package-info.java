/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */
/**
 * Does all arithmetic instructions
 * @author Adam Kuraczyński
 * @version 1.0
 */
package model;
