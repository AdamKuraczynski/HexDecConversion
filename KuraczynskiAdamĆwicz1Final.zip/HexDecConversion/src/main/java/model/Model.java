/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
/**
 * Conversion hex to dec and dec to hex
 * @author Adam Kuraczyński
 * @version 1.13
 */
public class Model {

    /**
     * Converts hex to dec value
     * @param hex_number - hex number as a parameter
     * @return - returns dec number
     */
    public int hexToDecimal(String hex_number) {
        String digits = "0123456789ABCDEF";  
        hex_number = hex_number.toUpperCase();  
        // Teporary supportive value decaration
        int val = 0;
        // For loop for manual conversion
        for (int i = 0; i < hex_number.length(); i++)  
            { 
                char c = hex_number.charAt(i);  
                int d = digits.indexOf(c);  
                val = 16*val + d;  
            }  
        return val;
    }

    /**
     * Converts dec to hex value
     * @param decimal_number - decimal number as a parameter
     * @return - returns hex number
     */
    public String decimalToHex(int decimal_number) {
        // Two teporary supportive value decaration
        int rem;  
        String hex_value="";  
        char hexchars[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
        // While loop for manual conversion
        while(decimal_number>0) 
            {  
                rem=decimal_number%16;   
                hex_value=hexchars[rem]+hex_value;   
                decimal_number=decimal_number/16;  
            }  
        return hex_value;  
    }
}
