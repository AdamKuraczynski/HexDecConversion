/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package main;
import controller.Controller;
import view.View;
import model.Model;
/**
 *
 * @author Adam Kuraczyński
 * @version 1.3
 */
public class Main {
/**
 * Class Initializes Model, View and Controller and uses manageUserInput method from controller object
 * @param args - parameters for main method, can be used to run application with parameters from command line
 */
    // Main method declaration for this Java Application
    public static void main(String[] args) {  
        // Initialize the object named Model
        Model model = new Model();
        // Initialize the object named View
        View view = new View();
        // Initialize the object named Controller and pass Model and View objects as parameters
        Controller controller = new Controller(model, view);  
        // Use method in object controller that manages user input
        controller.manageUserInput();
    }
}
